import FlaskApp.app

app = FlaskApp.app.app

if __name__ == '__main__':
    app.run()
