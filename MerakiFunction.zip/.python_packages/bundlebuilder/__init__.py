# Load the current version meta-attribute into the package.
from .version import __version__
